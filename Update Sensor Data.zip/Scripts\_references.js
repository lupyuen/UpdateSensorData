﻿// This file enables IntelliSense in Visual Studio

/// <reference path="_officeintellisense.js" />
/// <reference path="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.9.1.js" />
/// <reference path="https://appsforoffice.microsoft.com/lib/1.1/hosted/office.js" />
